export default function App() {
  return <h1>Hello world</h1>
}
